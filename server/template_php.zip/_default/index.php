<?php
	$hostname = exec('hostname');
	$name = array_shift(explode('.', $hostname));
	$ip = $_SERVER['SERVER_ADDR']; // exec('hostname -I');
	
	$site = 'https://www.deltazero.cz';
	$logo = '/d0.white.svg';
	$alt = 'ΔO';
	
?>
<!DOCTYPE html>
<html lang="cs">
<head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
  <title><?=$hostname?></title>

  <style>
		@import url('https://fonts.googleapis.com/css?family=Lato&display=swap');
	
    html, body { margin:0; width:100%; height:100%; }
		body { background:white; font:15px 'Lato', sans-serif; }
    header { padding:10px; box-sizing:border-box; color:#444;
			width:100%; height:100%; min-height:400px;
      display:flex; flex-direction:column; align-items:center; justify-content:center; }
    header h1 { margin:0; text-align:center; font-weight:normal; font-size:50px; }
		header p { margin-top:10px; color:#999; font-size:20px; }
		header a { display:block; margin:50px 0 20px 0; text-decoration:none; 
			width:auto; padding:25px 30px; background:#222; border-radius:9px; }
    header a img { width:100px; }

  </style>
</head>
<body>

<header>
  <h1> <?=$name?> </h1>
	<p> <?=$ip?> </p>
	
	<a href="<?=$site?>"><img src="<?=$logo?>" alt="<?=$alt?>" /></a>
	
</header>

</body>
</html>