<?php

if ( ! ($_SERVER['PHP_AUTH_USER'] == 'root'	&& md5($_SERVER['PHP_AUTH_PW']) == 'fbf5738baf17775834a27164992fbc64' ) ) {

    header('WWW-Authenticate: Basic realm="PHP Info"');
    header('HTTP/1.1 401 Unauthorized');
    
    echo 'No access for you today...';
    exit;
}

phpinfo();
